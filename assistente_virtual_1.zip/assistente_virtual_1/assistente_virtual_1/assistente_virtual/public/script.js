let recognition;
let isListening = false;

if ('webkitSpeechRecognition' in window) {
    recognition = new webkitSpeechRecognition();
    recognition.continuous = true;
    recognition.interimResults = true;
    recognition.lang = 'pt-BR';

    recognition.onresult = function(event) {
        const command = event.results[event.results.length - 1][0].transcript;
        document.getElementById('status-text').textContent = `Comando reconhecido: ${command}`;
        processCommand(command);
    };

    recognition.onerror = function(event) {
        console.error('Erro:', event.error);
        document.getElementById('status-text').textContent = `Erro: ${event.error}`;
    };
}

function processCommand(command) {
    const commandLower = command.toLowerCase();
    let response = '';

    if (commandLower.includes('iniciar decolagem')) {
        response = "Iniciando decolagem. Preparando contagem regressiva.";
        startCountdown();
    } else if (commandLower.includes('liberar primeiro estágio')) {
        response = "Liberando estágio 1. Estágio 1 liberado com sucesso.";
    } else if (commandLower.includes('liberar segundo estágio')) {
        response = "Liberando estágio 2. Estágio 2 liberado com sucesso.";
    } else if (commandLower.includes('pousar booster')) {
        response = "Iniciando procedimento de pouso do booster. Booster em descida controlada. Booster pousado com sucesso.";
    } else if (commandLower.includes('liberar satélite')) {
        response = "Satélite liberado e pronto para uso.";
    } else {
        response = "Comando não reconhecido";
    }

    document.getElementById('response-text').textContent = response;
}

function startCountdown() {
    let count = 10;
    const countdownInterval = setInterval(() => {
        document.getElementById('response-text').textContent = count;
        if (count === 0) {
            clearInterval(countdownInterval);
            document.getElementById('response-text').textContent = "Decolagem!";
        }
        count--;
    }, 1000);
}

document.getElementById('start-button').addEventListener('click', () => {
    if (recognition) {
        recognition.start();
        isListening = true;
        document.getElementById('start-button').disabled = true;
        document.getElementById('stop-button').disabled = false;
        document.getElementById('status-text').textContent = 'Escutando...';
        document.querySelector('.rocket-logo').classList.add('mic-active');
    }
});

document.getElementById('stop-button').addEventListener('click', () => {
    if (recognition) {
        recognition.stop();
        isListening = false;
        document.getElementById('start-button').disabled = false;
        document.getElementById('stop-button').disabled = true;
        document.getElementById('status-text').textContent = 'Microfone desativado';
        document.querySelector('.rocket-logo').classList.remove('mic-active');
    }
});