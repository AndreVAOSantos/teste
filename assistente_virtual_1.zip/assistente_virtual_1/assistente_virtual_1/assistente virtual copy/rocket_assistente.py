from flask import Flask, send_from_directory, request, jsonify
from inicializador_modelos import *
from transcritor import *
from threading import Thread
from nltk import word_tokenize, corpus
import secrets
import pyaudio
import wave
import json
import os
import time
import torch

AMOSTRAS = 1024
FORMATO = pyaudio.paInt16
CANAIS = 1
TEMPO_DE_GRAVACAO = 5
CAMINHO_AUDIO_FALA = "/misc/ifba/workspaces/inteligencia artificial/assistente virtual/temp/"
IDIOMA_CORPUS = "portuguese"
CONFIGURACAO = "configuration.json"

ATIVAR_INTERFACE_WEB = True

def criar_configuration_json():
    configuracao = {
        "nome_assistente": "Rocket",
        "comandos": [
            {
                "comando": "iniciar decolagem",
                "resposta": "Iniciando decolagem. Preparando contagem regressiva.",
                "acao": "contagem_regressiva"
            },
            {
                "comando": "liberar primeiro estágio",
                "resposta": "Liberando estágio 1. Estágio 1 liberado com sucesso.",
                "acao": "liberar_estagio_1"
            },
            {
                "comando": "liberar segundo estágio",
                "resposta": "Liberando estágio 2. Estágio 2 liberado com sucesso.",
                "acao": "liberar_estagio_2"
            },
            {
                "comando": "pousar booster",
                "resposta": "Iniciando procedimento de pouso do booster. Booster em descida controlada. Booster pousado com sucesso.",
                "acao": "pousar_booster"
            },
            {
                "comando": "liberar satelite",
                "resposta": "Satélite liberado e pronto para uso.",
                "acao": "liberar_satelite"
            }
        ]
    }
    
    with open(CONFIGURACAO, 'w') as f:
        json.dump(configuracao, f, indent=4)

def iniciar(dispositivo):
    criar_configuration_json()
    gravador = pyaudio.PyAudio()

    assistente_iniciado, processador, modelo = iniciar_modelo(MODELOS[0], dispositivo)

    palavras_de_parada = None
    if assistente_iniciado:
        palavras_de_parada = corpus.stopwords.words(IDIOMA_CORPUS)

        with open(CONFIGURACAO, "r") as arquivo_configuracao:
            configuracao = json.load(arquivo_configuracao)

    return assistente_iniciado, processador, modelo, gravador, palavras_de_parada, configuracao

def capturar_fala(gravador):
    gravacao = gravador.open(format=FORMATO, channels=CANAIS, rate=TAXA_AMOSTRAGEM, input=True, frames_per_buffer=AMOSTRAS)

    print("fale alguma coisa")

    fala = []
    for _ in range(0, int(TAXA_AMOSTRAGEM / AMOSTRAS * TEMPO_DE_GRAVACAO)):
        fala.append(gravacao.read(AMOSTRAS))

    gravacao.stop_stream()
    gravacao.close()

    print("fala capturada")

    return fala

def gravar_fala(fala, gravador):
    gravado, arquivo = False, f"{CAMINHO_AUDIO_FALA}/{secrets.token_hex(32).lower()}.wav" 

    try:
        wav = wave.open(arquivo, 'wb')
        wav.setnchannels(CANAIS)
        wav.setsampwidth(gravador.get_sample_size(FORMATO))
        wav.setframerate(TAXA_AMOSTRAGEM)
        wav.writeframes(b''.join(fala))
        wav.close()    

        gravado = True
    except Exception as e:
        print(f"ocorreu um erro gravando arquivo temporário: {str(e)}")

    return gravado, arquivo

def processar_comando(transcricao, configuracao):
    for comando in configuracao['comandos']:
        if comando['comando'].lower() in transcricao.lower():
            return comando
    return None

def executar_acao(comando):
    if comando['acao'] == 'contagem_regressiva':
        print(comando['resposta'])
        for i in range(10, -1, -1):
            print(f"{i}{'...' if i > 0 else ' Decolagem!'}")
            time.sleep(1)
    else:
        print(comando['resposta'])

def ativar_linha_de_comando(dispositivo, modelo, processador, gravador, palavras_de_parada, configuracao):
    while True:
        fala = capturar_fala(gravador)
        gravado, arquivo_fala = gravar_fala(fala, gravador)

        if gravado:
            transcricao = transcrever_fala(dispositivo, carregar_fala(arquivo_fala), modelo, processador)
            os.remove(arquivo_fala)

            print(f"transcrição: {transcricao}")

            comando = processar_comando(transcricao, configuracao)
            if comando:
                executar_acao(comando)

servico = Flask("rocket_assistente", static_folder="public")

@servico.route('/')
def serve_index():
    return send_from_directory('public', 'index.html')

@servico.route('/<path:path>')
def serve_static(path):
    return send_from_directory('public', path)

@servico.post("/reconhecer_comando")
def reconhecer_comando():
    if 'audio' not in request.files:
        return jsonify({"erro": "Nenhum arquivo de áudio encontrado"}), 400
    
    arquivo = request.files['audio']
    caminho_arquivo = os.path.join(CAMINHO_AUDIO_FALA, f"{secrets.token_hex(32).lower()}.wav")
    arquivo.save(caminho_arquivo)

    try:
        transcricao = transcrever_fala(servico.config["dispositivo"], carregar_fala(caminho_arquivo), servico.config["modelo"], servico.config["processador"])

        print(f"transcrição: {transcricao}")

        comando = processar_comando(transcricao, servico.config["configuracao"])
        if comando:
            executar_acao(comando)

        return jsonify({'transcription': transcricao})
    except Exception as e:
        print("Erro ao processar o áudio:", e)
        return jsonify({"erro": "Erro ao processar o áudio"}), 500
    finally:
        if os.path.exists(caminho_arquivo):
            os.remove(caminho_arquivo)

if __name__ == "__main__":
    dispositivo = "cuda:0" if torch.cuda.is_available() else "cpu"
    
    iniciado, processador, modelo, gravador, palavras_de_parada, configuracao = iniciar(dispositivo)
    if iniciado:
        if ATIVAR_INTERFACE_WEB:
            servico.config["dispositivo"] = dispositivo
            servico.config["modelo"] = modelo
            servico.config["processador"] = processador
            servico.config["palavras_de_parada"] = palavras_de_parada
            servico.config["configuracao"] = configuracao

            servico.run(debug=True)
        else:
            ativar_linha_de_comando(dispositivo, modelo, processador, gravador, palavras_de_parada, configuracao)
