import unittest
from assistente import *

LIGAR_LAMPADA = "/misc/ifba/workspaces/inteligencia artificial/assistente virtual/audios/ligar lampada.wav"
DESLIGAR_LAMPADA = "/misc/ifba/workspaces/inteligencia artificial/assistente virtual/audios/desligar lampada.wav"

class TesteLampada(unittest.TestCase):
    def setUp(self):
        self.dispositivo = "cuda:0" if torch.cuda.is_available() else "cpu"
        iniciado, self.processador, self.modelo, self.gravador, self.palavras_de_parada, self.acoes = iniciar(self.dispositivo)

        self.assertTrue(iniciado)

        return super().setUp()

    def test_ligar_lampada(self):
        transcricao = transcrever_fala(self.dispositivo, carregar_fala(LIGAR_LAMPADA), self.modelo, self.processador)
        self.assertIsNotNone(transcricao)

        comando = processar_transcricao(transcricao, self.palavras_de_parada)
        valido, acao, objeto = validar_comando(comando, self.acoes)

        self.assertTrue(valido)
        self.assertNotEqual(acao, "")
        self.assertNotEqual(objeto, "")

    def test_desligar_lampada(self):
        transcricao = transcrever_fala(self.dispositivo, carregar_fala(DESLIGAR_LAMPADA), self.modelo, self.processador)
        self.assertIsNotNone(transcricao)

        comando = processar_transcricao(transcricao, self.palavras_de_parada)
        valido, acao, objeto = validar_comando(comando, self.acoes)

        self.assertTrue(valido)
        self.assertNotEqual(acao, "")
        self.assertNotEqual(objeto, "")

if __name__ == "__main__":
    unittest.main() 