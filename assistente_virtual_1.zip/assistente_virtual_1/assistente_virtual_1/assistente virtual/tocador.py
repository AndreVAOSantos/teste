import pygame

MUSICA = "/misc/ifba/workspaces/inteligencia artificial/assistente virtual_/la belle de jour.mp3"

def iniciar_tocador(musica = MUSICA):
    pygame.init()
    pygame.mixer.init()
    pygame.mixer.music.load(musica)

    return True

def atuar_sobre_tocador(acao, objeto):
    if acao == "tocar" and objeto == "música":
        print("tocando música")

        pygame.mixer.music.play()
    elif acao == "parar" and objeto == "música":
        print("parando a música")

        pygame.mixer.music.stop()
